<?php
/**
 * Nexus checkout bootstrap — fixes blank checkout on custom template.
 *
 * @package Dejoiy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @return bool Request is from DEJOIY Library / Nexus (flow flag, URI, or referer).
 */
function dejoiy_library_is_nexus_add_request() {
	if ( function_exists( 'dejoiy_library_has_nexus_flow_request' ) && dejoiy_library_has_nexus_flow_request() ) {
		return true;
	}
	if ( function_exists( 'dejoiy_library_request_has_flow_flag' ) && dejoiy_library_request_has_flow_flag() ) {
		return true;
	}
	if ( function_exists( 'dejoiy_library_should_load_nexus_app' ) && dejoiy_library_should_load_nexus_app() ) {
		return true;
	}
	$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
	if ( '' !== $uri && preg_match( '#dejoiy-library|dejoiy_library=1|/nexus/(cart|checkout)(/|\?|$)#', $uri ) ) {
		return true;
	}
	$ref = wp_get_referer();
	if ( $ref && ( false !== strpos( $ref, 'dejoiy-library' ) || false !== strpos( $ref, 'dejoiy_library=1' ) || false !== strpos( $ref, '/nexus/cart' ) || false !== strpos( $ref, '/nexus/checkout' ) ) ) {
		return true;
	}
	return false;
}

/**
 * Total quantity of Nexus shelf lines in cart.
 *
 * @return int
 */
function dejoiy_library_get_nexus_cart_quantity() {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return 0;
	}
	$qty = 0;
	foreach ( WC()->cart->get_cart() as $item ) {
		if ( function_exists( 'dejoiy_library_cart_line_is_nexus' ) && dejoiy_library_cart_line_is_nexus( $item ) ) {
			$qty += isset( $item['quantity'] ) ? (int) $item['quantity'] : 0;
		}
	}
	return $qty;
}

/**
 * Prevent redirect away from Nexus checkout when shelf has books.
 *
 * @param bool $redirect Redirect.
 * @return bool
 */
function dejoiy_library_nexus_prevent_empty_checkout_redirect( $redirect ) {
	if ( function_exists( 'dejoiy_library_is_nexus_cart_context' ) && dejoiy_library_is_nexus_cart_context() ) {
		if ( function_exists( 'dejoiy_library_get_nexus_cart_quantity' ) && dejoiy_library_get_nexus_cart_quantity() > 0 ) {
			return false;
		}
	}
	return $redirect;
}

/**
 * Setup global post so WooCommerce checkout shortcode/template renders.
 */
function dejoiy_library_setup_checkout_page_globals() {
	if ( ! function_exists( 'wc_get_page_id' ) ) {
		return;
	}
	$page_id = wc_get_page_id( 'checkout' );
	if ( $page_id < 1 ) {
		return;
	}
	global $post, $wp_query;
	$post = get_post( $page_id ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
	if ( ! $post ) {
		return;
	}
	setup_postdata( $post );
	if ( $wp_query instanceof WP_Query ) {
		$wp_query->is_page     = true;
		$wp_query->is_singular = true;
	}
}

/**
 * Enqueue WooCommerce checkout assets on Nexus checkout template.
 */
function dejoiy_library_enqueue_nexus_checkout_assets() {
	if ( ! function_exists( 'dejoiy_library_use_checkout_template' ) || ! dejoiy_library_use_checkout_template() ) {
		return;
	}
	if ( ! function_exists( 'WC' ) ) {
		return;
	}
	wp_enqueue_style( 'woocommerce-general' );
	wp_enqueue_style( 'woocommerce-layout' );
	wp_enqueue_style( 'woocommerce-smallscreen' );
	wp_enqueue_script( 'wc-checkout' );
	wp_enqueue_script( 'wc-country-select' );
	wp_enqueue_script( 'wc-address-i18n' );
	if ( wp_script_is( 'selectWoo', 'registered' ) ) {
		wp_enqueue_script( 'selectWoo' );
	}
	if ( wp_style_is( 'select2', 'registered' ) ) {
		wp_enqueue_style( 'select2' );
	}
}

/**
 * Prepare cart and checkout object for Nexus template.
 */
function dejoiy_library_prepare_nexus_checkout() {
	if ( ! function_exists( 'WC' ) ) {
		return;
	}
	if ( function_exists( 'dejoiy_library_ensure_cart_loaded' ) ) {
		dejoiy_library_ensure_cart_loaded();
	}
	if ( function_exists( 'dejoiy_library_prune_cart_for_nexus_flow' ) ) {
		dejoiy_library_prune_cart_for_nexus_flow();
	}
	if ( WC()->cart ) {
		WC()->cart->calculate_totals();
	}
	dejoiy_library_setup_checkout_page_globals();
}

/**
 * Render checkout HTML (template + shortcode fallbacks).
 */
function dejoiy_library_render_nexus_checkout_html() {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		echo '<p class="dlu-reader-note">' . esc_html__( 'Nexus checkout is temporarily unavailable. Please try again.', 'dejoiy' ) . '</p>';
		return;
	}

	dejoiy_library_prepare_nexus_checkout();

	if ( function_exists( 'dejoiy_library_clear_stale_purchasable_notices' ) ) {
		dejoiy_library_clear_stale_purchasable_notices();
	}

	if ( function_exists( 'wc_print_notices' ) ) {
		wc_print_notices();
	}

	ob_start();
	if ( function_exists( 'woocommerce_checkout' ) ) {
		woocommerce_checkout();
	}
	$html = (string) ob_get_clean();

	if ( strlen( trim( wp_strip_all_tags( $html ) ) ) < 20 ) {
		ob_start();
		echo do_shortcode( '[woocommerce_checkout]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		$html = (string) ob_get_clean();
	}

	if ( strlen( trim( wp_strip_all_tags( $html ) ) ) < 20 && function_exists( 'wc_get_template' ) ) {
		ob_start();
		wc_get_template(
			'checkout/form-checkout.php',
			array(
				'checkout' => WC()->checkout(),
			)
		);
		$html = (string) ob_get_clean();
	}

	if ( strlen( trim( wp_strip_all_tags( $html ) ) ) < 20 ) {
		dejoiy_library_render_nexus_checkout_fallback();
		return;
	}

	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo $html;
}

/**
 * Minimal fallback when WC checkout templates fail (free / paid shelf).
 */
function dejoiy_library_render_nexus_checkout_fallback() {
	$cart = WC()->cart;
	echo '<div class="dlu-checkout-fallback woocommerce">';
	echo '<h3>' . esc_html__( 'Your Nexus shelf', 'dejoiy' ) . '</h3>';
	echo '<table class="shop_table woocommerce-checkout-review-order-table"><tbody>';
	foreach ( $cart->get_cart() as $item ) {
		if ( function_exists( 'dejoiy_library_cart_line_is_nexus' ) && ! dejoiy_library_cart_line_is_nexus( $item ) ) {
			continue;
		}
		$product = isset( $item['data'] ) && is_a( $item['data'], 'WC_Product' ) ? $item['data'] : wc_get_product( $item['product_id'] );
		if ( ! $product ) {
			continue;
		}
		echo '<tr><td>' . esc_html( $product->get_name() ) . ' × ' . (int) $item['quantity'] . '</td>';
		echo '<td>' . wp_kses_post( $product->get_price_html() ) . '</td></tr>';
	}
	echo '</tbody></table>';
	echo '<p class="dlu-checkout-total"><strong>' . esc_html__( 'Total:', 'dejoiy' ) . '</strong> ';
	echo wp_kses_post( $cart->get_total() );
	echo '</p>';
	echo '<form method="post" class="checkout woocommerce-checkout" action="' . esc_url( wc_get_checkout_url() ) . '">';
	wp_nonce_field( 'woocommerce-process_checkout', 'woocommerce-process-checkout-nonce' );
	echo '<input type="hidden" name="dejoiy_library" value="1" />';
	echo '<p class="form-row"><label>' . esc_html__( 'Email', 'dejoiy' ) . ' <abbr class="required">*</abbr></label>';
	echo '<input type="email" class="input-text" name="billing_email" required value="' . esc_attr( wp_get_current_user()->user_email ) . '" /></p>';
	echo '<p class="form-row"><button type="submit" class="button alt dlu-btn-primary" name="woocommerce_checkout_place_order" value="1">';
	esc_html_e( 'Place order', 'dejoiy' );
	echo '</button></p></form></div>';
}

/**
 * Register Nexus checkout fixes.
 */
function dejoiy_library_nexus_checkout_init() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}
	add_filter( 'woocommerce_checkout_redirect_empty_cart', 'dejoiy_library_nexus_prevent_empty_checkout_redirect', 99 );
	add_filter( 'woocommerce_checkout_update_order_review_expired', '__return_false', 99 );
	add_action( 'wp_enqueue_scripts', 'dejoiy_library_enqueue_nexus_checkout_assets', 25 );
}
add_action( 'woocommerce_init', 'dejoiy_library_nexus_checkout_init', 20 );

/**
 * After add-to-cart: ensure Nexus meta on lines added from library (WC AJAX).
 *
 * @param string $cart_item_key Cart key.
 * @param int    $product_id    Product.
 * @param int    $quantity      Qty.
 * @param int    $variation_id  Variation.
 * @param array  $variation     Variation.
 * @param array  $cart_item_data Data.
 */
function dejoiy_library_ensure_nexus_cart_meta( $cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	if ( ! function_exists( 'WC' ) || ! WC()->cart || ! function_exists( 'dejoiy_library_is_nexus_product' ) ) {
		return;
	}
	if ( ! dejoiy_library_is_nexus_product( $product_id ) || ! dejoiy_library_is_nexus_add_request() ) {
		return;
	}
	if ( ! empty( WC()->cart->cart_contents[ $cart_item_key ]['dejoiy_library_item'] ) ) {
		return;
	}
	WC()->cart->cart_contents[ $cart_item_key ]['dejoiy_library_item'] = 1;
	WC()->cart->set_session();
}
add_action( 'woocommerce_add_to_cart', 'dejoiy_library_ensure_nexus_cart_meta', 20, 6 );
