<?php
/**
 * Separate Nexus shelf cart from marketplace WooCommerce cart.
 *
 * @package Dejoiy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @return bool Viewing Nexus cart, checkout, or shelf with flow flag.
 */
function dejoiy_library_is_nexus_cart_context() {
	if ( function_exists( 'dejoiy_library_has_nexus_flow_request' ) && dejoiy_library_has_nexus_flow_request() ) {
		return true;
	}
	if ( ! did_action( 'wp' ) ) {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		return '' !== $uri && (bool) preg_match( '#/nexus/(cart|checkout)(/|\?|$)#', $uri );
	}
	$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
	if ( '' !== $uri && preg_match( '#/nexus/(cart|checkout)(/|\?|$)#', $uri ) ) {
		return true;
	}
	if ( function_exists( 'dejoiy_library_use_cart_template' ) && dejoiy_library_use_cart_template() ) {
		return true;
	}
	if ( function_exists( 'dejoiy_library_use_checkout_template' ) && dejoiy_library_use_checkout_template() ) {
		return true;
	}
	return false;
}

/**
 * @param array $cart_item Cart line.
 * @return bool
 */
function dejoiy_library_cart_line_is_nexus( $cart_item ) {
	if ( ! empty( $cart_item['dejoiy_library_item'] ) ) {
		return true;
	}
	$product_id = isset( $cart_item['product_id'] ) ? (int) $cart_item['product_id'] : 0;
	return $product_id && function_exists( 'dejoiy_library_is_nexus_product' ) && dejoiy_library_is_nexus_product( $product_id );
}

/**
 * @param bool   $visible   Visible.
 * @param array  $cart_item Item.
 * @param string $cart_key  Key.
 * @return bool
 */
function dejoiy_library_cart_item_visible( $visible, $cart_item, $cart_key ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	$is_nexus = dejoiy_library_cart_line_is_nexus( $cart_item );
	if ( dejoiy_library_is_nexus_cart_context() ) {
		return $is_nexus ? $visible : false;
	}
	return $is_nexus ? false : $visible;
}

/**
 * @param array $cart_item_data Data.
 * @param int   $product_id     Product.
 * @param int   $variation_id   Variation.
 * @return array
 */
function dejoiy_library_isolation_add_cart_item_data( $cart_item_data, $product_id, $variation_id ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	if ( ! function_exists( 'dejoiy_library_is_nexus_product' ) || ! dejoiy_library_is_nexus_product( $product_id ) ) {
		return $cart_item_data;
	}
	if ( function_exists( 'dejoiy_library_is_nexus_add_request' ) && dejoiy_library_is_nexus_add_request() ) {
		$cart_item_data['dejoiy_library_item'] = 1;
		return $cart_item_data;
	}
	$tag = dejoiy_library_is_nexus_cart_context()
		|| ( function_exists( 'dejoiy_library_has_nexus_flow_request' ) && dejoiy_library_has_nexus_flow_request() )
		|| ( function_exists( 'dejoiy_library_should_load_nexus_app' ) && dejoiy_library_should_load_nexus_app() );
	if ( $tag ) {
		$cart_item_data['dejoiy_library_item'] = 1;
	}
	return $cart_item_data;
}

/**
 * @param array  $cart_item     Item.
 * @param array  $values        Session values.
 * @param string $cart_item_key Key.
 * @return array
 */
function dejoiy_library_isolation_get_cart_item_from_session( $cart_item, $values, $cart_item_key ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	if ( isset( $values['dejoiy_library_item'] ) ) {
		$cart_item['dejoiy_library_item'] = $values['dejoiy_library_item'];
	}
	return $cart_item;
}

/**
 * @param bool $passed       Passed.
 * @param int  $product_id   Product.
 * @param int  $quantity     Qty.
 * @return bool
 */
function dejoiy_library_add_to_cart_validation( $passed, $product_id, $quantity ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	if ( ! $passed || ! function_exists( 'dejoiy_library_is_nexus_product' ) ) {
		return $passed;
	}

	$is_nexus = dejoiy_library_is_nexus_product( $product_id );
	$nexus_ui = dejoiy_library_is_nexus_cart_context()
		|| ( function_exists( 'dejoiy_library_has_nexus_flow_request' ) && dejoiy_library_has_nexus_flow_request() )
		|| ( function_exists( 'dejoiy_library_should_load_nexus_app' ) && dejoiy_library_should_load_nexus_app() );

	if ( $is_nexus && ! $nexus_ui ) {
		wc_add_notice(
			__( 'This book is only available through DEJOIY Nexus. Open the library to add it to your Nexus shelf.', 'dejoiy' ),
			'error'
		);
		return false;
	}

	if ( ! $is_nexus && dejoiy_library_is_nexus_cart_context() ) {
		wc_add_notice(
			__( 'Marketplace products cannot be added to your Nexus shelf. Use the main store cart instead.', 'dejoiy' ),
			'error'
		);
		return false;
	}

	if ( $is_nexus && $nexus_ui && function_exists( 'dejoiy_studio_is_customizable_product' ) && dejoiy_studio_is_customizable_product( $product_id ) ) {
		wc_add_notice(
			__( 'Custom Studio products belong in the Custom Studio cart, not your Nexus shelf.', 'dejoiy' ),
			'error'
		);
		return false;
	}

	return $passed;
}

/**
 * @return bool
 */
function dejoiy_library_cart_has_nexus_items() {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return false;
	}
	foreach ( WC()->cart->get_cart() as $item ) {
		if ( dejoiy_library_cart_line_is_nexus( $item ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Remove marketplace / studio lines when checking out in Nexus flow.
 */
function dejoiy_library_prune_cart_for_nexus_flow() {
	if ( ! dejoiy_library_is_nexus_cart_context() || ! function_exists( 'WC' ) || ! WC()->cart ) {
		return;
	}
	foreach ( WC()->cart->get_cart() as $key => $item ) {
		if ( ! dejoiy_library_cart_line_is_nexus( $item ) ) {
			WC()->cart->remove_cart_item( $key );
		}
	}
}

/**
 * Send customers with Nexus shelf items to Nexus checkout (flow flag required).
 */
function dejoiy_library_redirect_nexus_checkout() {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
		return;
	}
	if ( ! function_exists( 'is_checkout' ) || ! is_checkout() || is_wc_endpoint_url() ) {
		return;
	}
	if ( function_exists( 'dejoiy_library_has_nexus_flow_request' ) && dejoiy_library_has_nexus_flow_request() ) {
		dejoiy_library_prune_cart_for_nexus_flow();
		return;
	}
	if ( ! dejoiy_library_cart_has_nexus_items() ) {
		return;
	}
	$checkout_url = function_exists( 'dejoiy_library_get_checkout_url' )
		? dejoiy_library_get_checkout_url()
		: add_query_arg( DEJOIY_LIBRARY_FLOW, '1', wc_get_checkout_url() );
	wp_safe_redirect( $checkout_url );
	exit;
}

/**
 * Redirect Nexus cart when shelf has books but URL lacks flow flag.
 */
function dejoiy_library_redirect_nexus_cart() {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
		return;
	}
	if ( ! function_exists( 'is_cart' ) || ! is_cart() || is_wc_endpoint_url() ) {
		return;
	}
	if ( function_exists( 'dejoiy_library_has_nexus_flow_request' ) && dejoiy_library_has_nexus_flow_request() ) {
		dejoiy_library_prune_cart_for_nexus_flow();
		return;
	}
	if ( ! dejoiy_library_cart_has_nexus_items() ) {
		return;
	}
	$cart_url = function_exists( 'dejoiy_library_get_cart_url' )
		? dejoiy_library_get_cart_url()
		: add_query_arg( DEJOIY_LIBRARY_FLOW, '1', wc_get_cart_url() );
	wp_safe_redirect( $cart_url );
	exit;
}

/**
 * Block checkout when Nexus flow has no visible shelf lines.
 */
function dejoiy_library_validate_nexus_checkout() {
	if ( ! dejoiy_library_is_nexus_cart_context() ) {
		return;
	}
	if ( function_exists( 'dejoiy_library_cart_has_items' ) && dejoiy_library_cart_has_items() ) {
		return;
	}
	wc_add_notice(
		__( 'Your Nexus shelf is empty. Add a library book before checkout.', 'dejoiy' ),
		'error'
	);
}

/**
 * Remove stale WooCommerce "no longer purchasable" notices created while
 * moving Nexus books between the isolated shelf and Woo cart internals.
 *
 * The cart line itself is preserved by the Nexus context/purchasable guards;
 * this only prevents old validation notices from leaking into Nexus, Studio,
 * shop, product, cart, or checkout pages.
 */
function dejoiy_library_clear_stale_purchasable_notices() {
	if ( is_admin() || ! function_exists( 'wc_get_notices' ) || ! function_exists( 'wc_set_notices' ) ) {
		return;
	}
	if ( ! dejoiy_library_is_nexus_cart_context()
		&& ! ( function_exists( 'dejoiy_library_is_nexus_checkout_ajax' ) && dejoiy_library_is_nexus_checkout_ajax() )
		&& ! ( function_exists( 'dejoiy_library_cart_has_nexus_items' ) && dejoiy_library_cart_has_nexus_items() ) ) {
		return;
	}
	$notices = wc_get_notices();
	if ( empty( $notices ) || ! is_array( $notices ) ) {
		return;
	}

	$changed = false;
	foreach ( $notices as $type => $group ) {
		if ( ! is_array( $group ) ) {
			continue;
		}
		foreach ( $group as $index => $notice ) {
			$text = is_array( $notice ) && isset( $notice['notice'] ) ? (string) $notice['notice'] : (string) $notice;
			$plain = wp_strip_all_tags( $text );
			if ( false !== stripos( $plain, 'has been removed from your cart because it can no longer be purchased' )
				|| false !== stripos( $plain, 'session has expired' ) ) {
				unset( $notices[ $type ][ $index ] );
				$changed = true;
			}
		}
		if ( isset( $notices[ $type ] ) ) {
			$notices[ $type ] = array_values( $notices[ $type ] );
		}
	}

	if ( $changed ) {
		wc_set_notices( $notices );
	}
}

/**
 * Marketplace cart: drop Nexus lines so checkout totals stay correct.
 */
function dejoiy_library_prune_nexus_from_marketplace_cart() {
	if ( dejoiy_library_is_nexus_cart_context() ) {
		return;
	}
	if ( ! function_exists( 'is_cart' ) && ! function_exists( 'is_checkout' ) ) {
		return;
	}
	if ( ! ( ( function_exists( 'is_cart' ) && is_cart() ) || ( function_exists( 'is_checkout' ) && is_checkout() ) ) ) {
		return;
	}
	if ( function_exists( 'dejoiy_library_has_nexus_flow_request' ) && dejoiy_library_has_nexus_flow_request() ) {
		return;
	}
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return;
	}
	foreach ( WC()->cart->get_cart() as $key => $item ) {
		if ( dejoiy_library_cart_line_is_nexus( $item ) ) {
			WC()->cart->remove_cart_item( $key );
		}
	}
}

/**
 * Marketplace header mini-cart: exclude Nexus shelf lines from count.
 *
 * @param int $count Count.
 * @return int
 */
function dejoiy_library_cart_contents_count( $count ) {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return $count;
	}
	if ( dejoiy_library_is_nexus_cart_context()
		|| ( function_exists( 'dejoiy_library_has_nexus_flow_request' ) && dejoiy_library_has_nexus_flow_request() )
		|| ( function_exists( 'dejoiy_library_is_nexus_add_request' ) && dejoiy_library_is_nexus_add_request() ) ) {
		return function_exists( 'dejoiy_library_get_nexus_cart_quantity' )
			? dejoiy_library_get_nexus_cart_quantity()
			: $count;
	}
	$nexus_qty = 0;
	foreach ( WC()->cart->get_cart() as $item ) {
		if ( dejoiy_library_cart_line_is_nexus( $item ) ) {
			$nexus_qty += isset( $item['quantity'] ) ? (int) $item['quantity'] : 0;
		}
	}
	return max( 0, (int) $count - $nexus_qty );
}

/**
 * Register cart isolation (runs on every WooCommerce request).
 */

/**
 * Persist Nexus checkout context for WooCommerce AJAX (update_order_review).
 */
function dejoiy_library_flag_nexus_checkout_session() {
	if ( ! function_exists( 'WC' ) || ! WC()->session || ! function_exists( 'dejoiy_library_cart_has_nexus_items' ) ) {
		return;
	}
	if ( ! dejoiy_library_cart_has_nexus_items() ) {
		WC()->session->__unset( 'dejoiy_nexus_checkout' );
		return;
	}
	if ( dejoiy_library_is_nexus_cart_context()
		|| dejoiy_library_request_has_flow_flag()
		|| ( function_exists( 'dejoiy_library_is_nexus_checkout_ajax' ) && dejoiy_library_is_nexus_checkout_ajax() ) ) {
		WC()->session->set( 'dejoiy_nexus_checkout', '1' );
	}
}

function dejoiy_library_cart_isolation_init() {
	static $done = false;
	if ( $done || ! class_exists( 'WooCommerce' ) ) {
		return;
	}
	$done = true;

	add_filter( 'woocommerce_cart_item_visible', 'dejoiy_library_cart_item_visible', 10, 3 );
	add_filter( 'woocommerce_checkout_cart_item_visible', 'dejoiy_library_cart_item_visible', 10, 3 );
	add_filter( 'woocommerce_widget_cart_item_visible', 'dejoiy_library_cart_item_visible', 10, 3 );
	add_filter( 'woocommerce_add_cart_item_data', 'dejoiy_library_isolation_add_cart_item_data', 10, 3 );
	add_filter( 'woocommerce_get_cart_item_from_session', 'dejoiy_library_isolation_get_cart_item_from_session', 10, 3 );
	add_filter( 'woocommerce_add_to_cart_validation', 'dejoiy_library_add_to_cart_validation', 10, 3 );
	add_filter( 'woocommerce_cart_contents_count', 'dejoiy_library_cart_contents_count', 20, 1 );
	add_action( 'template_redirect', 'dejoiy_library_redirect_nexus_checkout', 4 );
	add_action( 'template_redirect', 'dejoiy_library_redirect_nexus_cart', 4 );
	add_action( 'template_redirect', 'dejoiy_library_prune_nexus_from_marketplace_cart', 5 );
	add_action( 'template_redirect', 'dejoiy_library_clear_stale_purchasable_notices', 99 );
	add_action( 'wp', 'dejoiy_library_clear_stale_purchasable_notices', 99 );
	add_action( 'woocommerce_before_checkout_form', 'dejoiy_library_clear_stale_purchasable_notices', 1 );
	add_action( 'woocommerce_before_cart', 'dejoiy_library_clear_stale_purchasable_notices', 1 );
	add_action( 'woocommerce_check_cart_items', 'dejoiy_library_flag_nexus_checkout_session', 1 );
	add_action( 'woocommerce_checkout_process', 'dejoiy_library_validate_nexus_checkout', 5 );

	if ( function_exists( 'dejoiy_library_nexus_product_purchasable' ) ) {
		add_filter( 'woocommerce_is_purchasable', 'dejoiy_library_nexus_product_purchasable', 10, 2 );
	}
	add_filter( 'woocommerce_cart_needs_payment', 'dejoiy_library_nexus_cart_needs_payment', 20, 2 );
	add_filter( 'woocommerce_cart_is_empty', 'dejoiy_library_nexus_cart_is_empty', 20, 1 );
}

/**
 * Free Nexus shelf checkout: allow placing order without payment gateway.
 *
 * @param bool   $needs_payment Needs payment.
 * @param object $cart          Cart.
 * @return bool
 */
function dejoiy_library_nexus_cart_needs_payment( $needs_payment, $cart ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	if ( ! dejoiy_library_is_nexus_cart_context() || ! function_exists( 'WC' ) || ! WC()->cart ) {
		return $needs_payment;
	}
	if ( ! dejoiy_library_cart_has_nexus_items() ) {
		return $needs_payment;
	}
	$total = (float) WC()->cart->get_total( 'edit' );
	return $total > 0.0001;
}

/**
 * WooCommerce "empty cart" should ignore hidden marketplace lines in Nexus checkout.
 *
 * @param bool $is_empty Empty.
 * @return bool
 */
function dejoiy_library_nexus_cart_is_empty( $is_empty ) {
	if ( ! dejoiy_library_is_nexus_cart_context() ) {
		return $is_empty;
	}
	if ( function_exists( 'dejoiy_library_cart_has_items' ) && dejoiy_library_cart_has_items() ) {
		return false;
	}
	return $is_empty;
}
