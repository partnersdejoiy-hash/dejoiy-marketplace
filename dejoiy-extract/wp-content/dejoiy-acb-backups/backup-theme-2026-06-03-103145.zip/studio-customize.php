<?php
/**
 * Studio customization fields, mock products, isolated WC pages.
 *
 * @package Dejoiy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Flow flag in current request (GET/POST/AJAX).
 *
 * @return bool
 */
function dejoiy_studio_request_has_flow_flag() {
	if ( isset( $_GET['dejoiy_studio'] ) && '1' === (string) $_GET['dejoiy_studio'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return true;
	}
	if ( isset( $_POST['dejoiy_studio'] ) && '1' === (string) $_POST['dejoiy_studio'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
		return true;
	}
	if ( ! empty( $_REQUEST['dejoiy_studio_ajax'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return true;
	}
	return false;
}

/**
 * Persist studio flow cookie (safe if headers already sent).
 */
function dejoiy_studio_set_flow_cookie() {
	if ( ! headers_sent() ) {
		setcookie( 'dejoiy_studio_flow', '1', time() + DAY_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
	}
	$_COOKIE['dejoiy_studio_flow'] = '1';
}

/**
 * Cart contains at least one studio line item.
 *
 * @return bool
 */
function dejoiy_studio_cart_has_studio_items() {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return false;
	}
	foreach ( WC()->cart->get_cart() as $item ) {
		if ( dejoiy_studio_cart_item_is_studio( $item ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Should cart/checkout links include ?dejoiy_studio=1 (studio chrome only)?
 *
 * Never true on marketplace pages — avoids changing wc_get_cart_url() globally.
 *
 * @return bool
 */
function dejoiy_studio_should_use_studio_urls() {
	if ( defined( 'DEJOIY_STUDIO_PAGE_ID' ) && is_page( DEJOIY_STUDIO_PAGE_ID ) ) {
		return true;
	}
	if ( ! dejoiy_studio_request_has_flow_flag() ) {
		return false;
	}
	if ( function_exists( 'dejoiy_studio_use_single_template' ) && dejoiy_studio_use_single_template() ) {
		return true;
	}
	if ( function_exists( 'dejoiy_studio_use_cart_template' ) && dejoiy_studio_use_cart_template() ) {
		return true;
	}
	if ( function_exists( 'dejoiy_studio_use_checkout_template' ) && dejoiy_studio_use_checkout_template() ) {
		return true;
	}
	return false;
}

/**
 * Append studio flow param when appropriate.
 *
 * @param string $url URL.
 * @return string
 */
function dejoiy_studio_flow_url( $url ) {
	if ( ! dejoiy_studio_should_use_studio_urls() ) {
		return $url;
	}
	return add_query_arg( 'dejoiy_studio', '1', $url );
}

/**
 * Ensure WooCommerce cart session is loaded (needed in Elementor / shortcode headers).
 */
function dejoiy_studio_ensure_cart_loaded() {
	if ( ! function_exists( 'WC' ) || ! WC() ) {
		return;
	}
	if ( is_null( WC()->cart ) && function_exists( 'wc_load_cart' ) ) {
		wc_load_cart();
	}
}

/**
 * Studio cart URL — always includes flow param (studio templates only).
 *
 * @return string
 */
function dejoiy_studio_get_cart_url() {
	dejoiy_studio_ensure_cart_loaded();
	$url = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/cart/' );
	return add_query_arg( 'dejoiy_studio', '1', remove_query_arg( 'dejoiy_studio', $url ) );
}

/**
 * Studio checkout URL — always includes flow param (studio templates only).
 *
 * @return string
 */
function dejoiy_studio_get_checkout_url() {
	dejoiy_studio_ensure_cart_loaded();
	$url = function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : home_url( '/checkout/' );
	return add_query_arg( 'dejoiy_studio', '1', remove_query_arg( 'dejoiy_studio', $url ) );
}

/**
 * Dedicated studio checkout (only with ?dejoiy_studio=1 and studio line items).
 *
 * @return bool
 */
function dejoiy_studio_use_checkout_template() {
	if ( ! function_exists( 'is_checkout' ) || ! is_checkout() || is_wc_endpoint_url() ) {
		return false;
	}
	if ( ! dejoiy_studio_request_has_flow_flag() ) {
		return false;
	}
	return dejoiy_studio_cart_has_studio_items();
}

/**
 * Boot studio customize module.
 */
function dejoiy_studio_customize_init() {
	add_action( 'init', 'dejoiy_studio_seed_mock_products', 30 );
	add_action( 'init', 'dejoiy_studio_refresh_mock_images', 31 );
	add_filter( 'woocommerce_product_single_add_to_cart_attributes', 'dejoiy_studio_cart_form_attributes' );
	add_filter( 'woocommerce_cart_item_visible', 'dejoiy_studio_cart_item_visible', 10, 3 );
	add_filter( 'woocommerce_checkout_cart_item_visible', 'dejoiy_studio_cart_item_visible', 10, 3 );
	add_action( 'woocommerce_before_add_to_cart_button', 'dejoiy_studio_render_customize_fields', 15 );
	add_filter( 'woocommerce_add_to_cart_validation', 'dejoiy_studio_validate_customize', 10, 3 );
	add_filter( 'woocommerce_add_cart_item_data', 'dejoiy_studio_add_cart_item_data', 10, 3 );
	add_filter( 'woocommerce_get_cart_item_from_session', 'dejoiy_studio_get_cart_item_from_session', 10, 3 );
	add_filter( 'woocommerce_get_item_data', 'dejoiy_studio_cart_item_display', 10, 2 );
	add_action( 'woocommerce_checkout_create_order_line_item', 'dejoiy_studio_order_line_item_meta', 10, 4 );
	add_action( 'woocommerce_admin_order_item_headers', 'dejoiy_studio_admin_order_headers' );
	add_action( 'woocommerce_admin_order_item_values', 'dejoiy_studio_admin_order_values', 10, 3 );
	add_filter( 'body_class', 'dejoiy_studio_wc_body_class' );
	add_action( 'wp_enqueue_scripts', 'dejoiy_studio_wc_assets', 1005 );
	add_filter( 'woocommerce_add_to_cart_fragments', 'dejoiy_studio_cart_fragments' );
	add_filter( 'woocommerce_add_to_cart_redirect', 'dejoiy_studio_ajax_add_to_cart_redirect', 20 );
	add_filter( 'woocommerce_add_to_cart_redirect', 'dejoiy_studio_flow_add_to_cart_redirect', 5 );
	add_filter( 'woocommerce_add_to_cart_form_action', 'dejoiy_studio_flow_form_action', 10, 1 );
	add_action( 'woocommerce_before_add_to_cart_button', 'dejoiy_studio_flow_hidden_field', 5 );
	add_action( 'woocommerce_before_single_product', 'dejoiy_studio_print_notices', 3 );
	add_filter( 'woocommerce_product_supports', 'dejoiy_studio_disable_ajax_add_to_cart', 10, 3 );
	add_action( 'woocommerce_add_to_cart', 'dejoiy_studio_set_cookie_on_add', 10, 6 );
	add_action( 'woocommerce_add_to_cart', 'dejoiy_studio_redirect_buy_now', 99, 6 );
	add_action( 'wp_enqueue_scripts', 'dejoiy_studio_dequeue_wc_ajax_atc', 1010 );
	add_action( 'wp_enqueue_scripts', 'dejoiy_studio_enqueue_chrome_assets', 1011 );
	add_action( 'template_redirect', 'dejoiy_studio_redirect_studio_checkout', 4 );
	add_filter( 'woocommerce_get_cart_url', 'dejoiy_studio_force_studio_wc_urls', 999 );
	add_filter( 'woocommerce_get_checkout_url', 'dejoiy_studio_force_studio_wc_urls', 999 );
	add_action( 'wp_ajax_dejoiy_studio_cart_count', 'dejoiy_studio_ajax_cart_count' );
	add_action( 'wp_ajax_nopriv_dejoiy_studio_cart_count', 'dejoiy_studio_ajax_cart_count' );
	add_filter( 'woocommerce_get_remove_url', 'dejoiy_studio_cart_remove_url', 10, 2 );
	add_filter( 'woocommerce_add_to_cart_redirect', 'dejoiy_studio_buy_now_checkout_redirect', 99 );
	add_filter( 'wp_get_referer', 'dejoiy_studio_cart_remove_referer', 10, 1 );
	add_action( 'wp_loaded', 'dejoiy_studio_cart_remove_redirect_fallback', 21 );
}
add_action( 'after_setup_theme', 'dejoiy_studio_customize_init' );

/**
 * @param array $classes Classes.
 * @return array
 */
function dejoiy_studio_wc_body_class( $classes ) {
	if ( function_exists( 'dejoiy_studio_is_screen' ) && dejoiy_studio_is_screen() ) {
		$classes[] = 'dejoiy-studio-screen';
	} elseif ( is_page( 4399 ) ) {
		$classes[] = 'dejoiy-studio-screen';
	}
	if (
		dejoiy_studio_use_single_template()
		|| ( function_exists( 'dejoiy_studio_use_cart_template' ) && dejoiy_studio_use_cart_template() )
		|| ( function_exists( 'dejoiy_studio_use_checkout_template' ) && dejoiy_studio_use_checkout_template() )
	) {
		$classes[] = 'dsu-studio-isolated';
	}
	return $classes;
}

/**
 * Enqueue WC studio skin.
 */
function dejoiy_studio_enqueue_chrome_assets() {
	if ( ! dejoiy_studio_is_studio_chrome_context() ) {
		return;
	}
	$uri = get_stylesheet_directory_uri();
	$dir = get_stylesheet_directory();
	$ver = '11.0.0';
	wp_enqueue_script(
		'dejoiy-studio-badge',
		$uri . '/studio-badge.js',
		array(),
		(string) ( file_exists( $dir . '/studio-badge.js' ) ? filemtime( $dir . '/studio-badge.js' ) : $ver ),
		true
	);
	wp_localize_script(
		'dejoiy-studio-badge',
		'DEJOIY_STUDIO_BADGE',
		array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'count'    => dejoiy_studio_cart_count(),
		)
	);
}

function dejoiy_studio_wc_assets() {
	if ( ! function_exists( 'dejoiy_studio_is_screen' ) || ! dejoiy_studio_is_screen() ) {
		return;
	}
	$uri = get_stylesheet_directory_uri();
	$dir = get_stylesheet_directory();
	$ver = '11.0.0';
	wp_enqueue_style(
		'dejoiy-studio-hf',
		$uri . '/studio-hf.css',
		array(),
		(string) ( file_exists( $dir . '/studio-hf.css' ) ? filemtime( $dir . '/studio-hf.css' ) : $ver )
	);
	wp_enqueue_style(
		'dejoiy-studio-single',
		$uri . '/studio-single.css',
		array( 'dejoiy-studio-hf' ),
		(string) ( file_exists( $dir . '/studio-single.css' ) ? filemtime( $dir . '/studio-single.css' ) : $ver )
	);

	if ( function_exists( 'dejoiy_studio_use_cart_template' ) && dejoiy_studio_use_cart_template() ) {
		if ( ! wp_script_is( 'dejoiy-studio-badge', 'enqueued' ) ) {
			dejoiy_studio_enqueue_chrome_assets();
		}
		wp_enqueue_script(
			'dejoiy-studio-cart',
			$uri . '/studio-cart.js',
			array(),
			(string) ( file_exists( $dir . '/studio-cart.js' ) ? filemtime( $dir . '/studio-cart.js' ) : $ver ),
			true
		);
	}

	if ( dejoiy_studio_use_single_template() ) {
		wp_enqueue_script( 'jquery' );
		if ( ! wp_script_is( 'dejoiy-studio-badge', 'enqueued' ) ) {
			dejoiy_studio_enqueue_chrome_assets();
		}
		wp_enqueue_script(
			'dejoiy-studio-wc',
			$uri . '/studio-wc.js',
			array( 'jquery', 'dejoiy-studio-badge' ),
			(string) ( file_exists( $dir . '/studio-wc.js' ) ? filemtime( $dir . '/studio-wc.js' ) : $ver ),
			true
		);
		$wc_ajax = class_exists( 'WC_AJAX' ) ? WC_AJAX::get_endpoint( '%%endpoint%%' ) : home_url( '/?wc-ajax=%%endpoint%%' );
		wp_localize_script(
			'dejoiy-studio-wc',
			'DEJOIY_STUDIO_WC',
			array(
				'ajax_url'   => admin_url( 'admin-ajax.php' ),
				'wc_ajax'    => $wc_ajax,
				'cart_url'     => dejoiy_studio_get_cart_url(),
				'checkout_url' => dejoiy_studio_get_checkout_url(),
				'i18n_added'   => __( 'Added to studio cart', 'dejoiy' ),
				'i18n_error'   => __( 'Could not add to cart. Check customization fields.', 'dejoiy' ),
				'i18n_buy_now' => __( 'Taking you to studio checkout…', 'dejoiy' ),
			)
		);
	}
}

/**
 * Minimal HTML document start (no theme header cards).
 */
function dejoiy_studio_document_start() {
	?><!DOCTYPE html>
	<html <?php language_attributes(); ?>>
	<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
	<?php wp_head(); ?>
	</head>
	<body <?php body_class( 'dsu-studio-isolated dejoiy-studio-flow' ); ?>>
	<?php wp_body_open(); ?>
	<?php
}

/**
 * Minimal document end.
 */
function dejoiy_studio_document_end() {
	wp_footer();
	echo '</body></html>';
}

/**
 * Create mock out-of-stock studio products once.
 */
function dejoiy_studio_seed_mock_products() {
	if ( get_option( 'dejoiy_studio_mocks_v11' ) || ! class_exists( 'WooCommerce' ) ) {
		return;
	}

	$mocks = array(
		array(
			'name'  => 'Studio Preview — Custom Tee',
			'price' => '599',
			'desc'  => 'Mock studio product for preview. Out of stock.',
			'img'   => 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=600&fit=crop',
		),
		array(
			'name'  => 'Studio Preview — Premium Mug',
			'price' => '349',
			'desc'  => 'Mock studio mug — upload your art at checkout.',
			'img'   => 'https://images.unsplash.com/photo-1514228742587-6b1558fcca0d?w=600&h=600&fit=crop',
		),
		array(
			'name'  => 'Studio Preview — Phone Case',
			'price' => '449',
			'desc'  => 'Mock phone case for studio walkthrough.',
			'img'   => 'https://images.unsplash.com/photo-1601784551446-20c9e07cdbdb?w=600&h=600&fit=crop',
		),
		array(
			'name'  => 'Studio Preview — Embroidered Cap',
			'price' => '399',
			'desc'  => 'Mock cap — text + logo customization.',
			'img'   => 'https://images.unsplash.com/photo-1588850561407-ed78c282e80b?w=600&h=600&fit=crop',
		),
		array(
			'name'  => 'Studio Preview — Tote Bag',
			'price' => '499',
			'desc'  => 'Mock tote for studio gallery display.',
			'img'   => 'https://images.unsplash.com/photo-1544810906-1bf05ed9a42f?w=600&h=600&fit=crop',
		),
	);

	$cat_ids = array();
	$custom  = get_term_by( 'slug', 'customized-products', 'product_cat' );
	if ( $custom && ! is_wp_error( $custom ) ) {
		$cat_ids[] = (int) $custom->term_id;
	}
	if ( empty( $cat_ids ) && defined( 'DEJOIY_STUDIO_CAT_IDS' ) ) {
		$cat_ids = DEJOIY_STUDIO_CAT_IDS;
	}

	foreach ( $mocks as $i => $mock ) {
		$product = new WC_Product_Simple();
		$product->set_name( $mock['name'] );
		$product->set_status( 'publish' );
		$product->set_regular_price( $mock['price'] );
		$product->set_short_description( $mock['desc'] );
		$product->set_catalog_visibility( 'visible' );
		$product->set_manage_stock( true );
		$product->set_stock_quantity( 0 );
		$product->set_stock_status( 'outofstock' );
		$product->set_sku( 'dejoiy-studio-mock-' . ( $i + 1 ) );
		$id = $product->save();
		if ( $id && ! empty( $cat_ids ) ) {
			wp_set_object_terms( $id, $cat_ids, 'product_cat' );
		}
		if ( $id ) {
			update_post_meta( $id, '_dejoiy_studio_mock', '1' );
			dejoiy_studio_attach_image_from_url( $id, $mock['img'] );
		}
	}

	update_option( 'dejoiy_studio_mocks_v11', '1' );
}

/**
 * Fallback image URLs for studio mock products (used when sideload fails).
 *
 * @return array<string, string>
 */
function dejoiy_studio_mock_image_map() {
	return array(
		'dejoiy-studio-mock-1' => 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800&h=800&fit=crop',
		'dejoiy-studio-mock-2' => 'https://images.unsplash.com/photo-1514228742587-6b1558fcca0d?w=800&h=800&fit=crop',
		'dejoiy-studio-mock-3' => 'https://images.unsplash.com/photo-1601784551446-20c9e07cdbdb?w=800&h=800&fit=crop',
		'dejoiy-studio-mock-4' => 'https://images.unsplash.com/photo-1588850561407-ed78c282e80b?w=800&h=800&fit=crop',
		'dejoiy-studio-mock-5' => 'https://images.unsplash.com/photo-1544810906-1bf05ed9a42f?w=800&h=800&fit=crop',
		'5008'                 => 'https://images.unsplash.com/photo-1514228742587-6b1558fcca0d?w=800&h=800&fit=crop',
		'5011'                 => 'https://images.unsplash.com/photo-1588850561407-ed78c282e80b?w=800&h=800&fit=crop',
		'5012'                 => 'https://images.unsplash.com/photo-1544810906-1bf05ed9a42f?w=800&h=800&fit=crop',
	);
}

/**
 * Product image for studio UI (thumbnail, fallback meta, or mock map).
 *
 * @param int    $product_id Product ID.
 * @param string $size       Image size.
 * @return string
 */
function dejoiy_studio_get_product_image_url( $product_id, $size = 'medium_large' ) {
	$product_id = (int) $product_id;
	$url        = get_the_post_thumbnail_url( $product_id, $size );
	if ( $url ) {
		return $url;
	}
	$meta = get_post_meta( $product_id, '_dejoiy_studio_img_url', true );
	if ( $meta ) {
		return (string) $meta;
	}
	$map = dejoiy_studio_mock_image_map();
	if ( isset( $map[ (string) $product_id ] ) ) {
		return $map[ (string) $product_id ];
	}
	if ( function_exists( 'wc_get_product' ) ) {
		$product = wc_get_product( $product_id );
		if ( $product ) {
			$sku = $product->get_sku();
			if ( $sku && isset( $map[ $sku ] ) ) {
				return $map[ $sku ];
			}
		}
	}
	if ( function_exists( 'wc_placeholder_img_src' ) ) {
		return wc_placeholder_img_src();
	}
	return '';
}

/**
 * Whether a product has a real image for studio UI (not the WC placeholder).
 *
 * @param int    $product_id Product ID.
 * @param string $size       Image size.
 * @return bool
 */
function dejoiy_studio_product_has_display_image( $product_id, $size = 'thumbnail' ) {
	$url = dejoiy_studio_get_product_image_url( (int) $product_id, $size );
	if ( '' === $url ) {
		return false;
	}
	if ( function_exists( 'wc_placeholder_img_src' ) && $url === wc_placeholder_img_src() ) {
		return false;
	}
	if ( false !== strpos( $url, 'woocommerce-placeholder' ) ) {
		return false;
	}
	return true;
}

/**
 * Retry sideload for mock products missing thumbnails (hourly).
 */
function dejoiy_studio_refresh_mock_images() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}
	if ( get_transient( 'dejoiy_studio_img_sync' ) ) {
		return;
	}

	$img_map = dejoiy_studio_mock_image_map();
	$skip_id = 4906;

	$mock_ids = get_posts(
		array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => 20,
			'fields'         => 'ids',
			'meta_key'       => '_dejoiy_studio_mock', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
		)
	);

	$needs_retry = false;
	foreach ( $mock_ids as $pid ) {
		$pid = (int) $pid;
		if ( $pid === $skip_id ) {
			continue;
		}
		$product = wc_get_product( $pid );
		if ( ! $product ) {
			continue;
		}
		$sku = $product->get_sku();
		$url = isset( $img_map[ $sku ] ) ? $img_map[ $sku ] : ( isset( $img_map[ (string) $pid ] ) ? $img_map[ (string) $pid ] : '' );
		if ( ! $url ) {
			continue;
		}
		update_post_meta( $pid, '_dejoiy_studio_img_url', esc_url_raw( $url ) );
		if ( ! has_post_thumbnail( $pid ) ) {
			$needs_retry = true;
			dejoiy_studio_attach_image_from_url( $pid, $url );
		}
	}

	set_transient( 'dejoiy_studio_img_sync', 1, $needs_retry ? 15 * MINUTE_IN_SECONDS : HOUR_IN_SECONDS );
}

/**
 * Cart line is from the custom studio flow.
 *
 * @param array $cart_item Cart item.
 * @return bool
 */
function dejoiy_studio_cart_item_is_studio( $cart_item ) {
	if ( ! empty( $cart_item['dejoiy_studio_item'] ) ) {
		return true;
	}
	$product_id = isset( $cart_item['product_id'] ) ? (int) $cart_item['product_id'] : 0;
	if ( ! $product_id ) {
		return false;
	}
	if ( get_post_meta( $product_id, '_dejoiy_studio_mock', true ) ) {
		return true;
	}
	return false;
}

/**
 * Update header cart badges after AJAX add.
 *
 * @param array $fragments Fragments.
 * @return array
 */
function dejoiy_studio_cart_fragments( $fragments ) {
	if (
		! dejoiy_studio_is_studio_chrome_context()
		&& empty( $_REQUEST['dejoiy_studio_ajax'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		&& ! dejoiy_studio_request_has_flow_flag()
	) {
		return $fragments;
	}
	$count = dejoiy_studio_cart_count();
	$badge = $count > 0
		? '<span class="dsu-hdr-badge" id="dsu-hdr-cart-count">' . (int) $count . '</span>'
		: '<span class="dsu-hdr-badge" id="dsu-hdr-cart-count" hidden></span>';
	$badge_mob = $count > 0
		? '<span class="dsu-hdr-badge dsu-hdr-badge--mob" id="dsu-hdr-cart-count-mob">' . (int) $count . '</span>'
		: '<span class="dsu-hdr-badge dsu-hdr-badge--mob" id="dsu-hdr-cart-count-mob" hidden></span>';

	$fragments['#dsu-hdr-cart-count']    = $badge;
	$fragments['#dsu-hdr-cart-count-mob'] = $badge_mob;
	return $fragments;
}

/**
 * Stay on product page after AJAX add (no slow redirect).
 *
 * @param string $url Redirect URL.
 * @return string|false
 */
function dejoiy_studio_ajax_add_to_cart_redirect( $url ) {
	if ( dejoiy_studio_is_flow() && ! empty( $_REQUEST['dejoiy_studio_ajax'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return false;
	}
	return $url;
}

/**
 * Buy-now request (theme / WooCommerce variants).
 *
 * @return bool
 */
function dejoiy_studio_is_buy_now_request() {
	if ( ! empty( $_REQUEST['dejoiy_studio_buy_now'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return true;
	}
	if ( isset( $_REQUEST['woocommerce-buy-now'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return true;
	}
	if ( isset( $_REQUEST['buy_now'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return true;
	}
	return false;
}

/**
 * Keep add-to-cart / buy-now redirects on studio cart & checkout.
 *
 * @param string $url Redirect URL.
 * @return string
 */
function dejoiy_studio_flow_add_to_cart_redirect( $url ) {
	if ( ! dejoiy_studio_request_has_flow_flag() ) {
		return $url;
	}
	dejoiy_studio_set_flow_cookie();
	if ( dejoiy_studio_is_buy_now_request() ) {
		return dejoiy_studio_get_checkout_url();
	}
	return remove_query_arg(
		array( 'add-to-cart', 'added-to-cart', 'quantity', 'product_id' ),
		dejoiy_studio_get_cart_url()
	);
}

/**
 * If checkout has studio items but URL lacks flow param, send to studio checkout.
 */
function dejoiy_studio_redirect_studio_checkout() {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
		return;
	}
	if ( ! function_exists( 'is_checkout' ) || ! is_checkout() || is_wc_endpoint_url() ) {
		return;
	}
	if ( dejoiy_studio_request_has_flow_flag() ) {
		return;
	}
	if ( ! dejoiy_studio_cart_has_studio_items() ) {
		return;
	}
	wp_safe_redirect( dejoiy_studio_get_checkout_url() );
	exit;
}

/**
 * On studio screens, force WC cart/checkout URLs to studio flow.
 *
 * @param string $url URL.
 * @return string
 */
function dejoiy_studio_force_studio_wc_urls( $url ) {
	if ( ! dejoiy_studio_is_studio_chrome_context() ) {
		return $url;
	}
	return add_query_arg( 'dejoiy_studio', '1', remove_query_arg( 'dejoiy_studio', $url ) );
}

/**
 * AJAX: studio cart badge count.
 */
function dejoiy_studio_ajax_cart_count() {
	dejoiy_studio_ensure_cart_loaded();
	wp_send_json_success(
		array(
			'count' => dejoiy_studio_cart_count(),
		)
	);
}

/**
 * Build remove URL for a studio cart line (explicit nonce + flow flag).
 *
 * @param string $cart_item_key Cart item key.
 * @return string
 */
function dejoiy_studio_get_remove_item_url( $cart_item_key ) {
	$cart_item_key = sanitize_text_field( (string) $cart_item_key );
	if ( '' === $cart_item_key ) {
		return dejoiy_studio_get_cart_url();
	}
	return wp_nonce_url(
		add_query_arg(
			array(
				'remove_item' => $cart_item_key,
			),
			dejoiy_studio_get_cart_url()
		),
		'woocommerce-cart'
	);
}

/**
 * Remove link stays in studio cart flow.
 *
 * @param string $url           Remove URL.
 * @param string $cart_item_key Cart item key.
 * @return string
 */
function dejoiy_studio_cart_remove_url( $url, $cart_item_key = '' ) {
	if ( ! dejoiy_studio_request_has_flow_flag() && ! dejoiy_studio_is_studio_chrome_context() ) {
		return $url;
	}
	if ( '' !== (string) $cart_item_key ) {
		return dejoiy_studio_get_remove_item_url( $cart_item_key );
	}
	return add_query_arg( 'dejoiy_studio', '1', remove_query_arg( 'dejoiy_studio', $url ) );
}

/**
 * After remove, WooCommerce redirects to wp_get_referer() — keep studio cart URL.
 *
 * @param string|false $referer Referer URL.
 * @return string|false
 */
function dejoiy_studio_cart_remove_referer( $referer ) {
	if ( empty( $_GET['remove_item'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return $referer;
	}
	if ( ! dejoiy_studio_request_has_flow_flag() ) {
		return $referer;
	}
	return dejoiy_studio_get_cart_url();
}

/**
 * If referer was missing, WooCommerce leaves remove_item on the URL — send user to studio cart.
 */
function dejoiy_studio_cart_remove_redirect_fallback() {
	if ( empty( $_GET['remove_item'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}
	if ( ! dejoiy_studio_request_has_flow_flag() ) {
		return;
	}
	if ( isset( $_GET['removed_item'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}
	if ( headers_sent() ) {
		return;
	}
	wp_safe_redirect( add_query_arg( 'removed_item', '1', dejoiy_studio_get_cart_url() ) );
	exit;
}

/**
 * Buy now → studio checkout (not studio cart).
 *
 * @param string $url Redirect URL.
 * @return string
 */
function dejoiy_studio_buy_now_checkout_redirect( $url ) {
	if ( dejoiy_studio_is_buy_now_request() && dejoiy_studio_request_has_flow_flag() ) {
		return dejoiy_studio_get_checkout_url();
	}
	return $url;
}

/**
 * @param string $action Form action URL.
 * @return string
 */
function dejoiy_studio_flow_form_action( $action ) {
	if ( function_exists( 'dejoiy_studio_use_single_template' ) && dejoiy_studio_use_single_template() ) {
		return dejoiy_studio_flow_url( $action );
	}
	return $action;
}

/**
 * Dequeue WC AJAX add-to-cart on studio single (breaks customization uploads).
 */
function dejoiy_studio_dequeue_wc_ajax_atc() {
	if ( function_exists( 'dejoiy_studio_use_single_template' ) && dejoiy_studio_use_single_template() ) {
		wp_dequeue_script( 'wc-add-to-cart' );
		wp_deregister_script( 'wc-add-to-cart' );
	}
}

/**
 * Studio products must use normal form POST (customization uploads).
 *
 * @param bool       $supported Supported.
 * @param string     $feature   Feature.
 * @param WC_Product $product   Product.
 * @return bool
 */
function dejoiy_studio_disable_ajax_add_to_cart( $supported, $feature, $product ) {
	if ( 'ajax_add_to_cart' === $feature && function_exists( 'dejoiy_studio_use_single_template' ) && dejoiy_studio_use_single_template() ) {
		return false;
	}
	return $supported;
}

/**
 * After buy-now POST, go straight to studio checkout.
 *
 * @param string $cart_item_key Cart item key.
 * @param int    $product_id    Product ID.
 * @param int    $quantity      Quantity.
 * @param int    $variation_id  Variation ID.
 * @param array  $variation     Variation.
 * @param array  $cart_item_data Item data.
 */
function dejoiy_studio_redirect_buy_now( $cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	if ( wp_doing_ajax() || ! dejoiy_studio_is_buy_now_request() || ! dejoiy_studio_request_has_flow_flag() ) {
		return;
	}
	if ( headers_sent() ) {
		return;
	}
	wp_safe_redirect( dejoiy_studio_get_checkout_url() );
	exit;
}

/**
 * Show validation / success notices on studio single product.
 */
function dejoiy_studio_print_notices() {
	if ( function_exists( 'dejoiy_studio_use_single_template' ) && dejoiy_studio_use_single_template() && function_exists( 'wc_print_notices' ) ) {
		wc_print_notices();
	}
}

/**
 * Hidden field so non-JS add to cart keeps studio flow.
 */
function dejoiy_studio_flow_hidden_field() {
	if ( ! function_exists( 'dejoiy_studio_use_single_template' ) || ! dejoiy_studio_use_single_template() ) {
		return;
	}
	echo '<input type="hidden" name="dejoiy_studio" value="1" />';
}

/**
 * @param string $cart_item_key Cart key.
 * @param int    $product_id    Product ID.
 * @param int    $quantity      Qty.
 * @param int    $variation_id  Variation.
 * @param array  $variation     Variation data.
 * @param array  $cart_item_data Cart item data.
 */
function dejoiy_studio_set_cookie_on_add( $cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	if (
		dejoiy_studio_request_has_flow_flag()
		&& ! empty( $cart_item_data['dejoiy_studio_item'] )
		&& function_exists( 'dejoiy_studio_is_customizable_product' )
		&& dejoiy_studio_is_customizable_product( $product_id )
	) {
		dejoiy_studio_set_flow_cookie();
	}
}

/**
 * Is the request rendering Custom Studio chrome (not marketplace)?
 *
 * @return bool
 */
function dejoiy_studio_is_studio_chrome_context() {
	if ( defined( 'DEJOIY_STUDIO_PAGE_ID' ) && is_page( DEJOIY_STUDIO_PAGE_ID ) ) {
		return true;
	}
	if ( function_exists( 'dejoiy_studio_use_single_template' ) && dejoiy_studio_use_single_template() ) {
		return true;
	}
	if ( function_exists( 'dejoiy_studio_use_cart_template' ) && dejoiy_studio_use_cart_template() ) {
		return true;
	}
	if ( function_exists( 'dejoiy_studio_use_checkout_template' ) && dejoiy_studio_use_checkout_template() ) {
		return true;
	}
	return dejoiy_studio_request_has_flow_flag();
}

/**
 * Cart badge count: studio items only on studio screens; full cart elsewhere.
 *
 * @return int
 */
function dejoiy_studio_cart_count() {
	dejoiy_studio_ensure_cart_loaded();
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return 0;
	}
	if ( ! dejoiy_studio_is_studio_chrome_context() ) {
		return (int) WC()->cart->get_cart_contents_count();
	}
	$count = 0;
	foreach ( dejoiy_studio_get_cart_studio_items() as $item ) {
		$count += isset( $item['quantity'] ) ? (int) $item['quantity'] : 0;
	}
	return $count;
}

/**
 * Studio cart line items for templates (avoids filtered WC count recursion).
 *
 * @return array<string, array>
 */
function dejoiy_studio_get_cart_studio_items() {
	dejoiy_studio_ensure_cart_loaded();
	$items = array();
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return $items;
	}
	foreach ( WC()->cart->get_cart() as $cart_key => $cart_item ) {
		if ( dejoiy_studio_cart_item_is_studio( $cart_item ) ) {
			$items[ $cart_key ] = $cart_item;
		}
	}
	return $items;
}

/**
 * Render studio cart table (safe — does not call woocommerce_cart()).
 *
 * @param array<string, array> $studio_items Cart items.
 */
function dejoiy_studio_render_cart_table( $studio_items ) {
	if ( empty( $studio_items ) || ! function_exists( 'WC' ) || ! WC()->cart ) {
		return;
	}

	dejoiy_studio_ensure_cart_loaded();
	WC()->cart->calculate_totals();

	wc_print_notices();

	$cart_url     = dejoiy_studio_get_cart_url();
	$checkout_url = dejoiy_studio_get_checkout_url();

	$subtotal = 0.0;
	?>
	<form class="woocommerce-cart-form" action="<?php echo esc_url( $cart_url ); ?>" method="post">
		<input type="hidden" name="dejoiy_studio" value="1" />
		<table class="shop_table shop_table_responsive cart woocommerce-cart-form__contents" cellspacing="0">
			<thead>
				<tr>
					<th class="product-remove"><span class="screen-reader-text"><?php esc_html_e( 'Remove item', 'woocommerce' ); ?></span></th>
					<th class="product-thumbnail"><span class="screen-reader-text"><?php esc_html_e( 'Thumbnail image', 'woocommerce' ); ?></span></th>
					<th class="product-name"><?php esc_html_e( 'Product', 'woocommerce' ); ?></th>
					<th class="product-price"><?php esc_html_e( 'Price', 'woocommerce' ); ?></th>
					<th class="product-quantity"><?php esc_html_e( 'Quantity', 'woocommerce' ); ?></th>
					<th class="product-subtotal"><?php esc_html_e( 'Subtotal', 'woocommerce' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ( $studio_items as $cart_key => $cart_item ) {
					$product_id = isset( $cart_item['product_id'] ) ? (int) $cart_item['product_id'] : 0;
					$_product   = isset( $cart_item['data'] ) && is_a( $cart_item['data'], 'WC_Product' )
						? $cart_item['data']
						: wc_get_product( $product_id );
					if ( ! $_product || ! $_product->exists() || empty( $cart_item['quantity'] ) ) {
						continue;
					}
					$product_permalink = $_product->is_visible() ? $_product->get_permalink() : '';
					if ( dejoiy_studio_is_flow() && $product_permalink ) {
						$product_permalink = add_query_arg( 'dejoiy_studio', '1', $product_permalink );
					}
					$subtotal += (float) $cart_item['line_subtotal'];
					?>
					<tr class="woocommerce-cart-form__cart-item cart_item">
						<td class="product-remove">
							<?php
							$remove_url = function_exists( 'dejoiy_studio_get_remove_item_url' )
								? dejoiy_studio_get_remove_item_url( $cart_key )
								: wc_get_cart_remove_url( $cart_key );
							?>
							<a href="<?php echo esc_url( $remove_url ); ?>" class="remove" aria-label="<?php esc_attr_e( 'Remove this item', 'woocommerce' ); ?>" data-cart_item_key="<?php echo esc_attr( $cart_key ); ?>">&times;</a>
						</td>
						<td class="product-thumbnail">
							<?php
							$thumbnail = $_product->get_image();
							if ( $product_permalink ) {
								printf( '<a href="%s">%s</a>', esc_url( $product_permalink ), $thumbnail ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							} else {
								echo $thumbnail; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							}
							?>
						</td>
						<td class="product-name" data-title="<?php esc_attr_e( 'Product', 'woocommerce' ); ?>">
							<?php
							if ( $product_permalink ) {
								printf( '<a href="%s">%s</a>', esc_url( $product_permalink ), wp_kses_post( $_product->get_name() ) );
							} else {
								echo wp_kses_post( $_product->get_name() );
							}
							echo wc_get_formatted_cart_item_data( $cart_item ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							?>
						</td>
						<td class="product-price" data-title="<?php esc_attr_e( 'Price', 'woocommerce' ); ?>">
							<?php echo wp_kses_post( WC()->cart->get_product_price( $_product ) ); ?>
						</td>
						<td class="product-quantity" data-title="<?php esc_attr_e( 'Quantity', 'woocommerce' ); ?>">
							<?php
							if ( $_product->is_sold_individually() ) {
								$min_quantity = 1;
								$max_quantity = 1;
							} else {
								$min_quantity = 0;
								$max_quantity = $_product->get_max_purchase_quantity();
							}
							if ( $max_quantity > 0 ) {
								printf(
									'<input type="number" class="input-text qty text" name="cart[%1$s][qty]" value="%2$d" min="%3$d" max="%4$d" step="1" inputmode="numeric" />',
									esc_attr( $cart_key ),
									(int) $cart_item['quantity'],
									(int) $min_quantity,
									(int) $max_quantity
								);
							} else {
								printf(
									'<input type="number" class="input-text qty text" name="cart[%1$s][qty]" value="%2$d" min="%3$d" step="1" inputmode="numeric" />',
									esc_attr( $cart_key ),
									(int) $cart_item['quantity'],
									(int) $min_quantity
								);
							}
							?>
						</td>
						<td class="product-subtotal" data-title="<?php esc_attr_e( 'Subtotal', 'woocommerce' ); ?>">
							<?php echo wp_kses_post( WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ) ); ?>
						</td>
					</tr>
					<?php
				}
				?>
			</tbody>
		</table>
		<button type="submit" class="button" name="update_cart" value="<?php esc_attr_e( 'Update cart', 'woocommerce' ); ?>"><?php esc_html_e( 'Update cart', 'woocommerce' ); ?></button>
		<?php wp_nonce_field( 'woocommerce-cart', 'woocommerce-cart-nonce' ); ?>
	</form>
	<div class="cart-collaterals">
		<div class="cart_totals">
			<h2><?php esc_html_e( 'Cart totals', 'woocommerce' ); ?></h2>
			<table cellspacing="0" class="shop_table shop_table_responsive">
				<tr class="cart-subtotal">
					<th><?php esc_html_e( 'Subtotal', 'woocommerce' ); ?></th>
					<td data-title="<?php esc_attr_e( 'Subtotal', 'woocommerce' ); ?>"><?php echo wp_kses_post( wc_price( $subtotal ) ); ?></td>
				</tr>
			</table>
			<div class="wc-proceed-to-checkout">
				<a href="<?php echo esc_url( $checkout_url ); ?>" class="checkout-button button alt wc-forward"><?php esc_html_e( 'Proceed to checkout', 'woocommerce' ); ?></a>
			</div>
		</div>
	</div>
	<?php
}

/**
 * Hide non-studio items on studio cart and checkout in flow.
 *
 * @param bool   $visible   Visible.
 * @param array  $cart_item Item.
 * @param string $cart_key  Key.
 * @return bool
 */
function dejoiy_studio_cart_item_visible( $visible, $cart_item, $cart_key ) {
	// Marketplace cart/checkout: show all items unchanged.
	if ( function_exists( 'dejoiy_studio_use_cart_template' ) && dejoiy_studio_use_cart_template() ) {
		return dejoiy_studio_cart_item_is_studio( $cart_item );
	}
	if ( function_exists( 'dejoiy_studio_use_checkout_template' ) && dejoiy_studio_use_checkout_template() ) {
		return dejoiy_studio_cart_item_is_studio( $cart_item );
	}
	return $visible;
}

/**
 * Sideload image URL as product thumbnail.
 *
 * @param int    $post_id Post ID.
 * @param string $url     Image URL.
 */
function dejoiy_studio_attach_image_from_url( $post_id, $url ) {
	if ( ! $url ) {
		return false;
	}
	update_post_meta( $post_id, '_dejoiy_studio_img_url', esc_url_raw( $url ) );

	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';

	$filter = static function ( $args ) {
		$args['user-agent'] = 'WordPress/' . get_bloginfo( 'version' ) . '; ' . home_url();
		$args['timeout']    = 30;
		return $args;
	};
	add_filter( 'http_request_args', $filter, 10, 1 );

	$tmp = download_url( $url, 30 );
	remove_filter( 'http_request_args', $filter, 10 );

	if ( is_wp_error( $tmp ) ) {
		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 30,
				'headers' => array(
					'User-Agent' => 'WordPress/' . get_bloginfo( 'version' ) . '; ' . home_url(),
				),
			)
		);
		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return false;
		}
		$body = wp_remote_retrieve_body( $response );
		if ( ! $body ) {
			return false;
		}
		$tmp = wp_tempnam( 'studio-mock-' . $post_id . '.jpg' );
		if ( ! $tmp ) {
			return false;
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		file_put_contents( $tmp, $body );
	}

	$file = array(
		'name'     => 'studio-mock-' . $post_id . '.jpg',
		'tmp_name' => $tmp,
	);
	$attach_id = media_handle_sideload( $file, $post_id );
	if ( ! is_wp_error( $attach_id ) ) {
		set_post_thumbnail( $post_id, $attach_id );
		return true;
	}
	// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
	@unlink( $tmp );
	return false;
}

/**
 * @param array $attrs Form attributes.
 * @return array
 */
function dejoiy_studio_cart_form_attributes( $attrs ) {
	if (
		function_exists( 'dejoiy_studio_use_single_template' )
		&& dejoiy_studio_use_single_template()
	) {
		$attrs['enctype'] = 'multipart/form-data';
	}
	return $attrs;
}

/**
 * Customization fields on single product.
 */
function dejoiy_studio_render_customize_fields() {
	if ( ! dejoiy_studio_request_has_flow_flag() ) {
		return;
	}
	?>
	<div class="dsu-customize" id="dsu-customize">
		<h3 class="dsu-customize-title">Your customization</h3>
		<p class="dsu-customize-hint">Add text and/or upload artwork. The seller receives these details with your order.</p>
		<label class="dsu-field" for="dejoiy_custom_text">
			<span>Custom text</span>
			<textarea id="dejoiy_custom_text" name="dejoiy_custom_text" rows="3" maxlength="500" placeholder="Name, quote, or print instructions…"></textarea>
		</label>
		<label class="dsu-field" for="dejoiy_custom_art">
			<span>Upload design image</span>
			<input type="file" id="dejoiy_custom_art" name="dejoiy_custom_art" accept="image/jpeg,image/png,image/webp,image/gif" />
		</label>
		<p class="dsu-customize-note">PNG or JPG up to 5MB. At least one field is required.</p>
	</div>
	<?php
}

/**
 * @param bool $passed   Passed.
 * @param int  $product_id Product.
 * @param int  $qty      Qty.
 * @return bool
 */
function dejoiy_studio_validate_customize( $passed, $product_id, $qty ) {
	if ( ! $passed ) {
		return $passed;
	}
	if (
		! dejoiy_studio_request_has_flow_flag()
		|| ! function_exists( 'dejoiy_studio_is_customizable_product' )
		|| ! dejoiy_studio_is_customizable_product( $product_id )
	) {
		return $passed;
	}
	$text = isset( $_POST['dejoiy_custom_text'] ) ? trim( wp_unslash( $_POST['dejoiy_custom_text'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
	$file = isset( $_FILES['dejoiy_custom_art'] ) ? $_FILES['dejoiy_custom_art'] : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing
	$has_file = ! empty( $file['name'] );
	if ( '' === $text && ! $has_file ) {
		wc_add_notice( __( 'Please add custom text or upload a design image for studio products.', 'dejoiy' ), 'error' );
		return false;
	}
	if ( $has_file && ! empty( $file['size'] ) && (int) $file['size'] > 5 * 1024 * 1024 ) {
		wc_add_notice( __( 'Design image must be 5MB or smaller.', 'dejoiy' ), 'error' );
		return false;
	}
	return $passed;
}

/**
 * @param array $cart_item_data Cart data.
 * @param int   $product_id     Product.
 * @param int   $variation_id   Variation.
 * @return array
 */
function dejoiy_studio_add_cart_item_data( $cart_item_data, $product_id, $variation_id ) {
	if ( ! dejoiy_studio_request_has_flow_flag() ) {
		return $cart_item_data;
	}
	if (
		! function_exists( 'dejoiy_studio_is_customizable_product' )
		|| ! dejoiy_studio_is_customizable_product( $product_id )
	) {
		return $cart_item_data;
	}
	$cart_item_data['dejoiy_studio_item'] = 1;
	if ( isset( $_POST['dejoiy_custom_text'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$text = sanitize_textarea_field( wp_unslash( $_POST['dejoiy_custom_text'] ) );
		if ( '' !== $text ) {
			$cart_item_data['dejoiy_custom_text'] = $text;
		}
	}
	if ( ! empty( $_FILES['dejoiy_custom_art']['name'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
		require_once ABSPATH . 'wp-admin/includes/file.php';
		$upload = wp_handle_upload(
			$_FILES['dejoiy_custom_art'], // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			array( 'test_form' => false )
		);
		if ( empty( $upload['error'] ) && ! empty( $upload['url'] ) ) {
			$cart_item_data['dejoiy_art_url'] = esc_url_raw( $upload['url'] );
		}
	}
	return $cart_item_data;
}

/**
 * Restore studio cart meta from session.
 *
 * @param array $cart_item     Cart item.
 * @param array $values        Session values.
 * @param string $cart_item_key Key.
 * @return array
 */
function dejoiy_studio_get_cart_item_from_session( $cart_item, $values, $cart_item_key ) {
	if ( isset( $values['dejoiy_studio_item'] ) ) {
		$cart_item['dejoiy_studio_item'] = $values['dejoiy_studio_item'];
	}
	if ( isset( $values['dejoiy_custom_text'] ) ) {
		$cart_item['dejoiy_custom_text'] = $values['dejoiy_custom_text'];
	}
	if ( isset( $values['dejoiy_art_url'] ) ) {
		$cart_item['dejoiy_art_url'] = $values['dejoiy_art_url'];
	}
	return $cart_item;
}

/**
 * @param array $item_data Item data.
 * @param array $cart_item  Cart item.
 * @return array
 */
function dejoiy_studio_cart_item_display( $item_data, $cart_item ) {
	if ( ! empty( $cart_item['dejoiy_custom_text'] ) ) {
		$item_data[] = array(
			'key'   => __( 'Custom text', 'dejoiy' ),
			'value' => wc_clean( $cart_item['dejoiy_custom_text'] ),
		);
	}
	if ( ! empty( $cart_item['dejoiy_art_url'] ) ) {
		$url = esc_url( $cart_item['dejoiy_art_url'] );
		$item_data[] = array(
			'key'   => __( 'Design file', 'dejoiy' ),
			'value' => '<a href="' . $url . '" target="_blank" rel="noopener">' . esc_html__( 'View upload', 'dejoiy' ) . '</a>',
		);
	}
	return $item_data;
}

/**
 * @param WC_Order_Item_Product $item          Item.
 * @param string                $cart_item_key Key.
 * @param array                 $values        Values.
 * @param WC_Order              $order         Order.
 */
function dejoiy_studio_order_line_item_meta( $item, $cart_item_key, $values, $order ) {
	if ( ! empty( $values['dejoiy_custom_text'] ) ) {
		$item->add_meta_data( __( 'Studio custom text', 'dejoiy' ), $values['dejoiy_custom_text'], true );
	}
	if ( ! empty( $values['dejoiy_art_url'] ) ) {
		$item->add_meta_data( __( 'Studio design file', 'dejoiy' ), $values['dejoiy_art_url'], true );
	}
}

/**
 * Admin order table header.
 */
function dejoiy_studio_admin_order_headers() {
	echo '<th>' . esc_html__( 'Studio customization', 'dejoiy' ) . '</th>';
}

/**
 * @param WC_Product|null $product Product.
 * @param WC_Order_Item   $item    Item.
 * @param int             $item_id Item ID.
 */
function dejoiy_studio_admin_order_values( $product, $item, $item_id ) {
	echo '<td>';
	$text = $item->get_meta( __( 'Studio custom text', 'dejoiy' ) );
	$file = $item->get_meta( __( 'Studio design file', 'dejoiy' ) );
	if ( $text ) {
		echo '<strong>' . esc_html__( 'Text:', 'dejoiy' ) . '</strong> ' . esc_html( $text ) . '<br>';
	}
	if ( $file ) {
		echo '<strong>' . esc_html__( 'File:', 'dejoiy' ) . '</strong> <a href="' . esc_url( $file ) . '" target="_blank">' . esc_html__( 'Download', 'dejoiy' ) . '</a>';
	}
	if ( ! $text && ! $file ) {
		echo '—';
	}
	echo '</td>';
}
